package www.cjf.com;



import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebViewCamera extends Activity{
	WebView webViewCamera;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			setContentView(R.layout.camera);
			webViewCamera = (WebView)findViewById(R.id.WebViewCamera);
			webViewCamera.loadUrl("www.baidu.com");
			//webViewCamera.
		}
}
