package www.cjf.com;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONException;
import org.json.JSONObject;

import www.cjf.com.webcam.MainActivity;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Description: <br/>
 * site: <a href="http://www.cjf.com">cjf</a> <br/>
 * Copyright (C), 2014-2015, CaiJunFeng <br/>
 * This program is protected by copyright laws. <br/>
 * Program Name:Forwarding Server <br/>
 * Date:
 * 
 * @author CaiJunFeng 540975464@qq.com
 * @version 1.0
 */
public class activity_main extends Activity {

	OutputStream os;
	Handler handler;

	private ImageView imageViewIllumination, imageViewTemperature,
			imageViewHumidity, imageViewLight, imageViewFan, imageViewCurtain,
			imageViewCamera, imageViewSetAuto, imageViewAbout,
			ImageViewTestVibrator, ImageViewTestLight;
	private AnimationDrawable animationDrawableFan, animationDrawableCurtain;
	private Animation animation;
	TextView textViewTemperature, textViewHumidity, textViewIllumination;
	double f_Temperature = 20;
	double f_Humidity = 50;
	double f_Illumination = 150;
	boolean bCurtain = true;
	boolean bLight = false;
	String openLight = "fa fb 07 05 00 00 00 00 00" + "\r\n";
	String closeLight = "fa fb 07 00 00 00 00 00 00" + "\r\n";
	String openFan = "fa fb 08 05 00 00 00 00 00" + "\r\n";
	String closeFan = "fa fb 08 00 00 00 00 00 00" + "\r\n";
	String openCurtain = "fa fb 08 05 00 00 00 00 00" + "\r\n";
	String closeCurtain = "fa fb 08 00 00 00 00 00 00" + "\r\n";
	boolean auto = false;
	Vibrator vibrator;
	Thread thread;
	private TimerTask timerTask;
	private Timer timer;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// ��ȡ��ϵͳ����
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

		textViewTemperature = (TextView) findViewById(R.id.textViewTemperature);
		textViewHumidity = (TextView) findViewById(R.id.textViewHumidity);
		textViewIllumination = (TextView) findViewById(R.id.textViewIllumination);

		imageViewIllumination = (ImageView) findViewById(R.id.imageViewIllumination);
		imageViewTemperature = (ImageView) findViewById(R.id.imageViewTemperature);
		imageViewHumidity = (ImageView) findViewById(R.id.imageViewHumidity);
		imageViewLight = (ImageView) findViewById(R.id.imageViewLight);
		imageViewFan = (ImageView) findViewById(R.id.imageViewFan);
		imageViewCurtain = (ImageView) findViewById(R.id.imageViewCurtain);
		imageViewCamera = (ImageView) findViewById(R.id.imageViewCamera);

		ImageViewTestLight = (ImageView) findViewById(R.id.ImageViewTestLight);
		ImageViewTestVibrator = (ImageView) findViewById(R.id.ImageViewTestVibrator);

		imageViewAbout = (ImageView) findViewById(R.id.imageViewAbout);
		imageViewSetAuto = (ImageView) findViewById(R.id.imageViewSetAuto);

		animationDrawableFan = (AnimationDrawable) imageViewFan.getDrawable();
		imageViewFan.setAnimation(animation);
		animationDrawableFan.stop();

		imageViewCurtain.setBackgroundResource(R.drawable.appcurtain6);

		imageViewTemperature.setBackgroundResource(R.drawable.apptemperature);

		timerTask = new TimerTask() {

			@Override
			public void run() {

				if (f_Temperature > 40) {
					f_Temperature = 20;
				} else {
					f_Temperature += 3;
				}

				if (f_Humidity > 100) {
					f_Humidity = 50;
				} else {
					f_Humidity += 10;
				}

				if (f_Illumination > 300) {
					f_Illumination = 150;
				} else {
					f_Illumination += 20;
				}

				JSONObject jsonObject = new JSONObject();
				try {
					jsonObject.put("f_Temperature", f_Temperature);
					jsonObject.put("f_Humidity", f_Humidity);
					jsonObject.put("f_Illumination", f_Illumination);

					Log.i("test", jsonObject.toString());
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Message msg = new Message();
				msg.what = 0x123;
				msg.obj = jsonObject;
				handler.sendMessage(msg);

			}
		};
		
		timer = new Timer();

		

		handler = new Handler() {
			private double d_Humidity;
			private double d_Temperature;
			private double d_Illumination;

			@Override
			public void handleMessage(Message msg) {
				// �����Ϣ���������߳�
				if (msg.what == 0x123) {

					JSONObject jSONObject = (JSONObject) msg.obj;

					try {
						d_Humidity = jSONObject.getDouble("f_Humidity");
						d_Temperature = jSONObject.getDouble("f_Temperature");
						d_Illumination = jSONObject.getDouble("f_Illumination");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if (auto) {
						if (d_Temperature > 30) {

							textViewTemperature.setText(d_Temperature + "��");

							imageViewTemperature
									.setBackgroundResource(R.drawable.apptemperature_warning);
							textViewTemperature.setTextColor((Color
									.parseColor("#EE4000")));

							vibrator.vibrate(2000);

						} else {

							textViewTemperature.setText(d_Temperature + "��");
							vibrator.cancel();
							imageViewTemperature
									.setBackgroundResource(R.drawable.apptemperature);
							textViewTemperature.setTextColor((Color
									.parseColor("#AEEEEE")));
						}

						if (d_Humidity > 80) {
							textViewHumidity.setText(d_Humidity + "%RH");
							animationDrawableFan.start();
						} else {

							textViewHumidity.setText(d_Humidity + "%RH");
							animationDrawableFan.stop();
						}

						if (d_Illumination > 200) {
							textViewIllumination
									.setText(d_Illumination + "Lux");
							imageViewCurtain
									.setBackgroundResource(R.anim.frameoff);
							animationDrawableCurtain = (AnimationDrawable) imageViewCurtain
									.getBackground();
							animationDrawableCurtain.start();
							bCurtain = true;
						} else {

							textViewIllumination
									.setText(d_Illumination + "Lux");
							imageViewCurtain
									.setBackgroundResource(R.anim.frameon);
							animationDrawableCurtain = (AnimationDrawable) imageViewCurtain
									.getBackground();
							animationDrawableCurtain.start();
							bCurtain = false;
						}

					}

				}
			}

		};

	}

	public void myClick(View view) throws UnsupportedEncodingException,
			IOException {
		switch (view.getId()) {

		case R.id.imageViewLight:

			if (bLight) {
				imageViewLight.setImageResource(R.drawable.applight_on);
				bLight = true;

			} else {
				imageViewLight.setImageResource(R.drawable.applight_off);
				bLight = false;

			}
			break;

		case R.id.ImageViewTestLight:

			if (ImageViewTestLight
					.getDrawable()
					.getConstantState()
					.equals(getResources().getDrawable(R.drawable.applight_off)
							.getConstantState())) {
				ImageViewTestLight.setImageResource(R.drawable.applight_on);

			} else {
				ImageViewTestLight.setImageResource(R.drawable.applight_off);

			}
			break;

		case R.id.imageViewFan:

			if (animationDrawableFan.isRunning()) {
				animationDrawableFan.stop();

			} else {
				animationDrawableFan.start();
			}

			break;

		case R.id.imageViewCurtain:

			if (bCurtain) {
				imageViewCurtain.setBackgroundResource(R.anim.frameon);
				animationDrawableCurtain = (AnimationDrawable) imageViewCurtain
						.getBackground();
				animationDrawableCurtain.start();
				bCurtain = false;
			} else {
				imageViewCurtain.setBackgroundResource(R.anim.frameoff);
				animationDrawableCurtain = (AnimationDrawable) imageViewCurtain
						.getBackground();
				animationDrawableCurtain.start();
				bCurtain = true;

			}

			break;

		case R.id.imageViewCamera:

			Intent intent2 = new Intent(activity_main.this, MainActivity.class);
			startActivity(intent2);
			break;

		case R.id.imageViewAbout:

			Intent intentAbout = new Intent(activity_main.this, About.class);
			startActivity(intentAbout);
			break;

		case R.id.imageViewSetAuto:
			if (auto) {
				// thread.stop();
				timer.cancel();
				auto = false;
				Toast.makeText(activity_main.this, "ȡ���Զ�ģʽ", 0).show();
			}

			else {
				// �����̣߳�ģ�����ݷ���
				// thread.start();							
				timer.schedule(timerTask, 1000, 2000);				
				auto = true;
				Toast.makeText(activity_main.this, "�����Զ�ģʽ", 0).show();
			}

			break;

		case R.id.ImageViewTestVibrator:
			if (auto) {
				auto = false;
				vibrator.vibrate(3000);
			} else {
				auto = true;
				vibrator.cancel();
			}
			Toast.makeText(activity_main.this, "��δ���Ӹù���", 0).show();

			break;

		default:
			break;
		}
	}
}