package www.cjf.com.webcam;

public class Configuration {

	//	id, name, host, port, user, pass, audio_buffer_time
	public static final String IPCAMERA_ID = "";
	public static final String IPCAMERA_NAME = "";
	public static final String IPCAMERA_HOST = "192.168.1.9";
	public static final String IPCAMERA_PORT = "80";
	public static final String IPCAMERA_USER = "admin";
	public static final String IPCAMERA_PASSWORD = "";
	public static final int IPCAMERA_AUDIO_BUFFER_TIME = 100;
	
}
