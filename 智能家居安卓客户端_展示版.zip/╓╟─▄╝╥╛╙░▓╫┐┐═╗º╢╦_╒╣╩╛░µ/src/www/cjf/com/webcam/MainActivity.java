package www.cjf.com.webcam;


import www.cjf.com.R;

import com.misc.objc.NSData;
import com.misc.objc.NSNotification;
import com.misc.objc.NSNotificationCenter;
import com.misc.objc.NSSelector;



import net.reecam.IpCamera;
import net.reecam.SimpleAudioTrack;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public class MainActivity extends Activity {
	public static Bitmap bitmap;
	private ImageView ivVideo = null;
	private ToggleButton tbVideo = null;
	private ToggleButton tbAudio = null;
	private IpCamera camera = null;
	private Thread apthread = null;
	private Handler mChildHandler;
	public static Bitmap mBitmap = null;
	GestureDetector mGestureDetector = null;
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// ���ر���
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);// ����ȫ��
		setContentView(R.layout.web_camera);

		init();

		camera = new IpCamera(Configuration.IPCAMERA_ID,
				Configuration.IPCAMERA_NAME, Configuration.IPCAMERA_HOST,
				Configuration.IPCAMERA_PORT, Configuration.IPCAMERA_USER,
				Configuration.IPCAMERA_PASSWORD,
				Configuration.IPCAMERA_AUDIO_BUFFER_TIME);

		mGestureDetector = new GestureDetector(this, new MyGestureListener());
	}

	private void init() {

		ivVideo = (ImageView) findViewById(R.id.iv_video);
		tbVideo = (ToggleButton) findViewById(R.id.tb_video);
		tbAudio = (ToggleButton) findViewById(R.id.tb_audio);
	}

	public void myClick(View v) {
		switch (v.getId()) {
		case R.id.btn_left_right_repeat:
			if (((ToggleButton) v).isChecked()) {
				camera.ptz_control(IpCamera.PTZ_COMMAND.P_PATROL);
			} else {
				camera.ptz_control(IpCamera.PTZ_COMMAND.P_PATROL_STOP);
			}
			break;
		case R.id.btn_up_down_repeat:
			if (((ToggleButton) v).isChecked()) {
				camera.ptz_control(IpCamera.PTZ_COMMAND.T_PATROL);
			} else {
				camera.ptz_control(IpCamera.PTZ_COMMAND.T_PATROL_STOP);
			}
			break;
		case R.id.btn_pt_center:

			camera.ptz_control(IpCamera.PTZ_COMMAND.PT_CENTER);

			break;
		case R.id.btn_io_turn:
			if (((ToggleButton) v).isChecked()) {
				camera.ptz_control(IpCamera.PTZ_COMMAND.IO_ON);
			} else {
				camera.ptz_control(IpCamera.PTZ_COMMAND.IO_OFF);
			}
			break;
		case R.id.tb_video:
			if (((ToggleButton) v).isChecked()) {
				camera.play_video();
			} else {
				camera.stop_video();
			}
			break;
		case R.id.tb_audio:
			if (((ToggleButton) v).isChecked()) {
				camera.play_audio();
			} else {
				camera.stop_audio();
			}
			break;
		case R.id.btn_jietu:
				mBitmap = this.bitmap;
			//if (mBitmap != null) {
				Intent intent = new Intent(this, PreviewActivity.class);
				//intent.putExtra("bitmap", mBitmap);
				startActivity(intent);
			//}
			break;
		default:
			break;
		}
	}

	/**
	 * ͼ��ı�ص�
	 * 
	 * @param note
	 */
	public void onImageChanged(NSNotification note) {
		if (!((IpCamera) note.object()).equals(camera)) {
			return;
		}

		NSData data = (NSData) note.userInfo().get("data");
		

		try {
			bitmap = BitmapFactory.decodeByteArray(data.bytes(), 0,
					data.length());
			//mBitmap = bitmap;
		} catch (OutOfMemoryError error) {
			NSNotificationCenter nc = NSNotificationCenter.defaultCenter();
			nc.removeObserver(this, IpCamera.IPCamera_Image_Notification,
					camera);
			nc.addObserver(this, new NSSelector("onImageChanged"),
					IpCamera.IPCamera_Image_Notification, camera);
			System.gc();
			return;
		}

		ivVideo.post(new Runnable() {

			@Override
			public void run() {
				ivVideo.setImageBitmap(bitmap);
			}

		});
	}

	/**
	 * ����ͷ����״̬�ı�
	 * 
	 * @param note
	 */
	public void onCameraStatusChanged(NSNotification note) {

		String status = note.userInfo().get("status").toString();

		//Log.i("tag", status);

		if ("CONNECTED".equals(status)) {
			camera.play_video();
		}

	}

	/**
	 * ����״̬�ı�
	 * 
	 * @param note
	 */
	public void onAlermStatusChanged(NSNotification note) {
		// String status = note.userInfo().get("status").toString();

		if (camera.alarm_status.equals(IpCamera.ALARM_STATUS.MOTION_DETECTING)) {
			Log.i("tag", "�ƶ�����״̬!!!!!!!!!!!!!!!!!!!!!!!!!");
		} else if (camera.alarm_status
				.equals(IpCamera.ALARM_STATUS.TRIGGER_DETECTING)) {
			Log.i("tag", "���뾯��״̬�ı�!!!!!!!!!!!!!!!!!!!!!!!!!");
		} else if (camera.alarm_status
				.equals(IpCamera.ALARM_STATUS.SOUND_DETECTING)) {
			Log.i("tag", "��������״̬�ı�!!!!!!!!!!!!!!!!!!!!!!!!!");
		} else if (camera.alarm_status
				.equals(IpCamera.ALARM_STATUS.UNKNOWN_ALARM)) {
			Log.i("tag", "δ֪����״̬�ı�!!!!!!!!!!!!!!!!!!!!!!!!!");
		} else if (camera.alarm_status.equals(IpCamera.ALARM_STATUS.NONE)) {
			Log.i("tag", "��!!!!!!!!!!!!!!!!!!!!!!!!!");
		}

	}

	public void onVideoStatusChanged(NSNotification note) {

		String status = note.userInfo().get("status").toString();
		if ("PLAYING".equals(status)) {
			tbVideo.post(new Runnable() {

				@Override
				public void run() {
					tbVideo.setChecked(true);

				}

			});
		} else if ("STOPED".equals(status)) {
			tbVideo.post(new Runnable() {

				@Override
				public void run() {
					tbVideo.setChecked(false);

				}

			});
		}

	}

	public void onAudioStatusChanged(NSNotification note) {

		String status = note.userInfo().get("status").toString();
		if ("PLAYING".equals(status)) {

			startAudioPlay();

			tbAudio.post(new Runnable() {

				@Override
				public void run() {
					tbAudio.setChecked(true);

				}

			});
		} else if ("STOPED".equals(status)) {

			stopAudioPlay();

			tbAudio.post(new Runnable() {

				@Override
				public void run() {
					tbAudio.setChecked(false);
				}

			});
		}
	}

	@Override
	protected void onResume() {
		if (getRequestedOrientation() != ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		super.onResume();

		NSNotificationCenter nc = NSNotificationCenter.defaultCenter();
		nc.addObserver(this, new NSSelector("onImageChanged"),
				IpCamera.IPCamera_Image_Notification, camera);
		nc.addObserver(this, new NSSelector("onCameraStatusChanged"),
				IpCamera.IPCamera_CameraStatusChanged_Notification, camera);
		nc.addObserver(this, new NSSelector("onAlermStatusChanged"),
				IpCamera.IPCamera_AlarmStatusChanged_Notification, camera);
		nc.addObserver(this, new NSSelector("onVideoStatusChanged"),
				IpCamera.IPCamera_VideoStatusChanged_Notification, camera);
		nc.addObserver(this, new NSSelector("onAudioStatusChanged"),
				IpCamera.IPCamera_AudioStatusChanged_Notification, camera);

		if (!camera.started) {
			camera.start();
		}
		if ("CONNECTED".equals(camera.camera_status.toString())) {
			camera.play_video();
		}

	}

	@Override
	protected void onPause() {
		super.onPause();

		camera.stop_video();
		camera.stop_audio();

		NSNotificationCenter nc = NSNotificationCenter.defaultCenter();
		nc.removeObserver(this, IpCamera.IPCamera_Image_Notification, camera);

	}

	public void OnAudio(NSNotification note) {
		// ֪ͨ�߳�
		if (mChildHandler != null) {
			Message msg = mChildHandler.obtainMessage();
			msg.obj = note;
			mChildHandler.sendMessage(msg);
		}
	}

	protected void startAudioPlay() {
		apthread = new Thread(new Runnable() {

			public void run() {
				final SimpleAudioTrack audioTrack;

				try {
					// ����һ���µ�AudioTrack����ʹ����ͬ�Ĳ�����ΪAudioRecord
					audioTrack = new SimpleAudioTrack(8000,
							AudioFormat.CHANNEL_CONFIGURATION_MONO,
							AudioFormat.ENCODING_PCM_16BIT);
					// ��ʼ�ط�
					audioTrack.init();
					Log.e("AudioTrack", "Ready");
					// ����Ƶ���嵽AudioTrack����

				} catch (Throwable t) {
					Log.e("AudioTrack", "Playback Failed");
					return;
				}

				Looper.prepare();
				mChildHandler = new Handler() {
					public void handleMessage(Message msg) {
						NSNotification note = (NSNotification) msg.obj;
						if (note == null) {
							// ����ֹͣ
							mChildHandler = null;
							Log.e("AudioTrack", "Playback Quit");
							Looper.myLooper().quit();
						} else {
							// ������Ƶ����
							int play_time = (Integer) note.userInfo().get(
									"tick");
							int now_time = IpCamera.times(null);
							if ((play_time - now_time) < -10) {
								// drop delayed packet
								// Log.e("AudioTrack", "Drop delayed packet " +
								// (now_time - get_time));
								return;
							}
							NSData data = (NSData) note.userInfo().get("data");
							audioTrack.playAudioTrack(data.bytes(), 0,
									data.length());
						}
					}
				};

				Looper.loop();
			}
		});
		apthread.start();
		NSNotificationCenter nc = NSNotificationCenter.defaultCenter();
		nc.addObserver(this, new NSSelector("OnAudio"),
				IpCamera.IPCamera_Audio_Notification, camera);
	}

	/**
	 * ������ֹͣ��Ƶ
	 */
	protected void stopAudioPlay() {
		NSNotificationCenter nc = NSNotificationCenter.defaultCenter();
		nc.removeObserver(this, IpCamera.IPCamera_Audio_Notification, camera);
		// nc.removeObserver(this,
		// IpCamera.IPCamera_AudioStatusChanged_Notification, camera);
		// notify audio play thread to stop
		if (mChildHandler != null) {
			Message msg = mChildHandler.obtainMessage();
			msg.obj = null;
			mChildHandler.sendMessage(msg);
		}

		apthread = null;
	}

	class MyGestureListener extends GestureDetector.SimpleOnGestureListener {

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {

			float x = e1.getX() - e2.getX();
			float y = e1.getY() - e2.getY();

			if (y <= 50 && y >= -50) { // ����

				if (x > 120) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.P_RIGHT);

				} else if (x < -120) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.P_LEFT);

				}

			} else if (y > 120) {

				if (x <= 50 && x >= -50) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.T_DOWN);

				} else if (x > 120) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.PT_RIGHT_DOWN);

				} else if (x < -120) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.PT_LEFT_DOWN);

				}

			} else if (y < -120) {

				if (x <= 50 && x >= -50) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.T_UP);

				} else if (x > 120) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.PT_RIGHT_UP);

				} else if (x < -120) {

					camera.ptz_control(IpCamera.PTZ_COMMAND.PT_LEFT_UP);

				}

			}

			return false;
		}

	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {

		mGestureDetector.onTouchEvent(event);

		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			camera.ptz_control(IpCamera.PTZ_COMMAND.PT_STOP);
		}
		return false;
	}

	protected void onDestroy() {
		super.onDestroy();
	}

}
