package www.cjf.com.webcam;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import www.cjf.com.R;





import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

public class PreviewActivity extends Activity {
	private final static String PICTURE_PATH = Environment
			.getExternalStorageDirectory() + "/znjj_Picture";
	private ImageView ivPreview = null;
	private Bitmap bitmap = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_preview);

		ivPreview = (ImageView) findViewById(R.id.iv_preview);
		//bitmap = getIntent().getParcelableExtra("bitmap");
		
		ivPreview.setImageBitmap(MainActivity.mBitmap);
		this.Folder();
	}

	public void myClick(View v) {
		switch (v.getId()) {
		case R.id.btn_save:
			bitmap = MainActivity.mBitmap;
					File imageFile = new File(PICTURE_PATH + "/1.png");
					if (imageFile.exists()) {
						imageFile.delete();
					}
					try {
						OutputStream os = new FileOutputStream(imageFile);
						bitmap.compress(Bitmap.CompressFormat.PNG, 0, os);
						os.flush();
						os.close();
						Toast.makeText(getApplicationContext(),
						"����ɹ���·����"+ PICTURE_PATH +"/1.png",
						Toast.LENGTH_SHORT).show();
						
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(),
								"����ʧ�ܣ�·����"+ PICTURE_PATH +"/1.png",
								Toast.LENGTH_SHORT).show();
						// TODO: handle exception
					}
						
			break;
		case R.id.btn_cancel:
			this.finish();
			break;
		}
	}
	//�����ļ���
	private static void Folder() {
		try {
			File dirFile = new File(PICTURE_PATH + "/");
		} catch (Exception e) {
			//Toast.makeText(PreviewActivity.this, "�����ļ��Aʧ��", 1000).show();
			// TODO: handle exception
		}

	}

}
