package www.cjf.com;

/**
 * Description: <br/>
 * site: <a href="http://www.cjf.com">cjf</a> <br/>
 * Copyright (C), 2014-2015, CaiJunFeng <br/>
 * This program is protected by copyright laws. <br/>
 * Program Name:Forwarding Server <br/>
 * Date:
 * 
 * @author CaiJunFeng 540975464@qq.com
 * @version 1.0
 */


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Login extends Activity {

	EditText editTextSetIP , editTextSetPORT;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		editTextSetIP = (EditText) findViewById(R.id.editTextSetIP);
		editTextSetPORT = (EditText) findViewById(R.id.editTextSetPORT);
	}
	
	public void login(View view){
		
		Bundle bundle = new Bundle();
		bundle.putString("ip", editTextSetIP.getText().toString().trim());
		bundle.putString("port", editTextSetPORT.getText().toString().trim());
		Intent intent = new Intent(Login.this,activity_main.class);
		intent.putExtras(bundle);
		startActivity(intent);
	}
}
